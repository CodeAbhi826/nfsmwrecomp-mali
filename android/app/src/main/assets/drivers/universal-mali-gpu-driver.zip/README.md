# MaliCompat Universal GPU Driver for ARM Mali

This driver package wraps the vendor Mali Vulkan driver to provide compatibility fixes for games and emulators running on ARM Mali Bifrost & Valhall GPUs (e.g. Mali-G71, G72, G76, G77, G78, G710, G715).

## Compatibility & Target Emulators
1. **Yuzu / Suyu / Sudachi / Skyline:**
   - Go to Settings -> GPU Driver Manager -> Install GPU Driver.
   - Select this .zip file.
2. **Winlator / Mobox / Box64Droid:**
   - Place this driver into the custom Turnip/Mali driver selection menu.
3. **Vita3K Android:**
   - Go to Settings -> GPU -> Custom Driver -> Install .zip.
4. **Android Native Recompilations:**
   - Directly loaded via libadrenotools or MaliCompat Cvar `--gpu_driver=malicompat`.

## Features
- Hardware dual-target dispatcher routing WSI swapchain surfaces to the Android system loader.
- Virtualized descriptor indexing (`descriptorIndexing`, `runtimeDescriptorArray`).
- 4-descriptor-set adaptation for Mali Bifrost architectures.
- BC texture decompression fallback for Mali hardware without BC1-BC7 support.
